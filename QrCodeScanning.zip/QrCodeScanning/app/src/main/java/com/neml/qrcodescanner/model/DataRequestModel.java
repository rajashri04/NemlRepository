package com.neml.qrcodescanner.model;

public class DataRequestModel {
    String qrCode;

    public String getQrCode() {
        return qrCode;
    }

    public void setQrCode(String qrCode) {
        this.qrCode = qrCode;
    }
}
